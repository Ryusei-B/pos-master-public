from django.views import View
from django.shortcuts import render
from django.shortcuts import redirect
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from .nohin_service import NohinService
from .shohin_service import ShohinService
from .forms import ShohinForm
from .forms import NohinForm
from .forms import NohinDetail
from .forms import NohinDetailFormset

class ShohinListView(View):
    def get(self, request, *args, **kwargs):
        '''
        商品一覧画面-初期表示処理
        '''
        # raise ApplicationException() # 例外テスト
        service = ShohinService(self.request)
        params = {
            'shohin_list': service.retrieveShohinList()
        }

        return render(request, 'shohin/list.html', params)

class ShohinRegistView(View):
    def get(self, request, *args, **kwargs):
        '''
        商品登録画面-初期表示処理
        '''
        params = {
            'mode': 'regist',
            'form': ShohinForm()
        }
        return render(request, 'shohin/regist.html', params)

    def post(self, request, *args, **kwargs):
        '''
        商品登録画面-登録処理
        '''
        form = ShohinForm(request.POST)

        if not form.is_valid():
            params = {
                'mode': 'regist',
                'form': form
            }
            return render(request, 'shohin/regist.html', params)
    
        service = ShohinService(request)

        # 登録済みチェック
        #if service.existShohin(form.cleaned_data['shohin_jan_code']):
        #    form.add_error('shohin_jan_code', '既に登録されている型番です。未登録の型番を入力してください。')
        #    params = {
        #       'mode': 'regist',
        #        'form': form
        #    }
        #    return render(request, 'shohin/regist.html', params)
            
        # 商品を登録する
        service.registShohin(form)
        messages.success(request, '商品情報を登録しました。')
        
        # 商品一覧画面の初期表示処理へリダイレクト
        return redirect(reverse('shohin_list_view'))

class ShohinUpdateView(View):
    def get(self, request, *args, **kwargs):
        '''商品更新画面-初期表示処理'''
        
        shohin_jan_code = request.GET['shohin_jan_code']
        shohin = ShohinService(request).retrieveShohin(shohin_jan_code)
        
        if not shohin:
            messages.error(request, '商品情報の取得に失敗しました。')
            return redirect(reverse('shohin_list_view'))

        params = {
            'mode': 'update',
            'form': ShohinForm(list(shohin)[0])
        }

        return render(request, 'shohin/regist.html', params)

    def post(self, request, *args, **kwargs):
        '''商品更新画面-更新処理'''
       
        service = ShohinService(request)
        shohin_jan_code = request.POST.get('shohin_jan_code')
        shohin = service.retrieveShohinModel(shohin_jan_code)

        if not shohin:
            messages.error(request, '商品情報の更新に失敗しました。')
            return redirect(reverse('shohin_list_view'))

        form = ShohinForm(request.POST, instance=shohin)

        if not form.is_valid():
            params = {
                'mode': 'update',
                'form': form
            }
            return render(request, 'shohin/regist.html', params)

        # 商品情報を更新
        service.updateShohin(form)
        messages.success(request, '商品情報を更新しました。')

        # 商品一覧画面の初期表示処理へリダイレクト
        return redirect(reverse('shohin_list_view'))

class ShohinDeleteView(View):
    def post(self, request, *args, **kwargs):
        '''
        商品一覧画面-削除処理
        '''
        ShohinService(request).deleteShohin(request.POST.get("shohin_jan_code"))
        messages.success(request, '商品情報を削除しました。')
        return redirect(reverse('shohin_list_view'))
        
class NohinListView(View):
    def get(self, request, *args, **kwargs):
        '''納品一覧画面-初期表示処理'''
        
        mode = self.kwargs.get('mode')
        service = NohinService(self.request)
        params = {
            'nohin_list': service.retrieveNohinList(),
            'mode': mode
        }

        return render(request, 'nohin/list.html', params)

class NohinRegistView(View):
    def get(self, request, *args, **kwargs):
        '''納品登録画面-初期表示処理'''
        
        service = NohinService(self.request)
        form = NohinForm()
        #formset = NohinDetailFormset(None, queryset=NohinDetail.objects.none())

        params = {
            'mode': 'regist',
            'form': form,
            #'formset': formset,
            'shohin_json': service.retrieveShohin(),
        #    'company_json': service.retrieveCompany(),
        }

        return render(request, 'nohin/regist.html', params)

    def post(self, request, *args, **kwargs):
        '''納品登録画面-登録処理'''
        
        service = NohinService(self.request)
        form = NohinForm(request.POST)
        detailFormset = NohinDetailFormset(request.POST)

        if (not form.is_valid()) or (not detailFormset.is_valid()):
            params = {
                'mode': 'regist',
                'form': form,
                'formset': detailFormset,
                'shohin_json': service.retrieveShohin(),
        #        'company_json': service.retrieveCompany(),
            }
            return render(request, 'nohin/regist.html', params)

        # 納品を登録する
        #service.registCompany(form.cleaned_data['nohinsaki'])
        service.registNohin(form, detailFormset)
        messages.success(request, '納品情報を登録しました。')

        # 納品登録画面初期表示処理へリダイレクト
        return redirect(reverse('nohin_list_view'))
        
class NohinUpdateView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        '''納品更新画面-初期表示処理'''
        
        nohinId = request.GET['nohin_id']
        service = NohinService(request)
        nohin = service.retrieveNohin(nohinId)
        
        if not nohin:
            messages.error(request, '納品情報の取得に失敗しました。')
            return redirect(reverse('nohin_list_view'))

        form = NohinForm(list(nohin)[0])
        #formset = NohinDetailFormset(None, queryset=service.retrieveNohinDetailList(nohinId))

        params = {
            'mode': 'update',
            'form': form,
        #    'formset': formset,
            'shohin_json': service.retrieveShohin(),
        #    'company_json': service.retrieveCompany(),
            'update_nohin_id': nohinId,
        }

        return render(request, 'nohin/regist.html', params)

    def post(self, request, *args, **kwargs):
        '''納品更新画面-更新処理'''
        
        nohinId = request.POST['update_nohin_id']
        service = NohinService(request)

        nohin = service.retrieveNohinModel(nohinId)
        nohinDetails = service.retrieveNohinDetailModelByNohin(nohin)

        form = NohinForm(request.POST, instance=nohin)
        #formset = NohinDetailFormset(request.POST, queryset=nohinDetails)

        '''
        if not form.is_valid() or not formset.is_valid():
            params = {
                'mode': 'update',
                'form': NohinForm(request.POST),
            #    'formset': NohinDetailFormset(request.POST),
                'shohin_json': service.retrieveShohin(),
                'company_json': service.retrieveCompany(),
                'update_nohin_id': nohinId,
            }
            return render(request, 'nohin/regist.html', params)
        '''
        # 納品を登録する
        #service.updateNohin(form, formset)
        #service.registCompany(form.cleaned_data['nohinsaki'])
        messages.success(request, '納品情報を更新しました。')
        
        # 納品一覧画面の初期表示処理へリダイレクト
        return redirect(reverse('nohin_list_view'))

class NohinDeleteView(LoginRequiredMixin, View):
    def post(self, request, *args, **kwargs):
        '''納品一覧画面-削除処理'''
        
        NohinService(request).deleteNohin(request.POST.get("nohin_id"))
        messages.success(request, '納品情報を削除しました。')
        return redirect(reverse('nohin_list_view'))