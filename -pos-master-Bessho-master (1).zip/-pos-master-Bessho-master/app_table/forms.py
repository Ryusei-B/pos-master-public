from django import forms
from .models import Shohin
from django.forms import modelformset_factory
from .models import Nohin
from .models import NohinDetail

class ShohinForm(forms.ModelForm):
    '''商品フォーム'''
    class Meta:
        model = Shohin
        fields = {'shohin_jan_code', 'shohin_name', 'shohin_price', 'shohin_zaikosu', 'shohin_memo'}
        widgets ={
            'shohin_jan_code': forms.TextInput(
                attrs = {
                    'type'  : 'number',
                    'class' : 'form-control form-control-lg',
                }),
            'shohin_name': forms.TextInput(
                attrs = {
                    'class' : 'form-control form-control-lg',
                }),
            'shohin_price' : forms.TextInput(
                attrs = {
                   'type' : 'number',
                   'min'  : 0,
                   'class': 'form-control form-control-lg',
                   'style': 'width: 17rem;'
                }),
            'shohin_zaikosu' : forms.TextInput(
                attrs ={
                   'type' : 'number',
                   'min'  : 0,
                   'class': 'form-control form-control-lg',
                   'style': 'width: 17rem;' 
                }),
            'shohin_memo' : forms.Textarea(
                attrs = {
                    'rows' : '10',
                    'class': 'form-control form-control-lg',
                }),
        }
class NohinForm(forms.ModelForm):
    '''納品フォーム'''
    class Meta:
        model = Nohin
        fields = {'nohin_date','nohin_nohinsaki','nohin_memo'}
        widgets = {
            'nohin_date': forms.DateInput(
                attrs = {
                    'id': 'regist_nohin_date',
                    'type': 'date',
                    'style': 'width: 17rem',
                    'class': 'form-control form-control-lg'
                }),
            'nohin_nohinsaki': forms.TextInput(
                attrs = {
                    #'id': 'regist_nohinsaki',
                    'type': 'serch',
                    #'list': 'company_list',
                    'class': 'form-control form-control-lg', 
                }),
            'nohin_memo': forms.Textarea(
                attrs ={
                   'id': 'regist_memo',
                   'rows': '3',
                   'class': 'form-control form-control-lg',
                }),
        }
class NohinDetailFrom(forms.ModelForm):
    '''納品詳細フォーム'''
    class Meta:
        model = NohinDetail
        fields = {'nohindetail_jan_code','nohindetail_price','nohindetail_amount'}
        widgets ={
            'nohindetail_jan_code': forms.TextInput(
                attrs ={
                   'type': 'serch',
                   'list': 'shohin_list',
                   'class': 'form-control form-control-lg js_shohin',
                }),
            'nohindetail_price': forms.TextInput(
                attrs = {
                    'type': 'number',
                    'min': '0',
                    'class' : 'form-control form-control-lg js_price',
                }),
            'nohindetail_amount': forms.TextInput(
                attrs = {
                    'type': 'number',
                    'min': '0',
                    'class' : 'form-control form-control-lg js_amount',
                }),
        }
NohinDetailFormset = modelformset_factory(
    NohinDetail,
    form = NohinDetailFrom,
    extra = 5,
    max_num = 5,
    can_delete = True,
)