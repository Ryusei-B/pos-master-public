from django.apps import AppConfig


class AppTableConfig(AppConfig):
    name = 'app_table'
