from django.db import models
from django.utils import timezone
# Create your models here.

class BaseModel(models.Model):
    '''モデル共通'''
regist_date = models.DateTimeField(verbose_name='登録日時')
regist_user = models.CharField(verbose_name='登録ユーザ', max_length=50)
update_date = models.DateTimeField(verbose_name='更新日時', null=True)

class Meta:
    abstract =True
    
class Shohin(BaseModel):
    '''商品'''
    shohin_jan_code = models.CharField(verbose_name='JANコード', max_length=13)
    shohin_name = models.CharField(verbose_name='商品名',max_length=50)
    shohin_zaikosu = models.IntegerField(verbose_name='在庫数')
    shohin_price = models.IntegerField(verbose_name='単価')
    shohin_memo =models.TextField(verbose_name='メモ', max_length=200, null=True, blank=True)
    '''
    class Meta:
            unique_together=(('kataban'))
    '''
    def __str__(self):
        return '{}, {}, {}, {},'.format(self.shohin_jan_code, self.shohin_zaikosu, self.shohin_price, self.shohin_name)

'''        
class Company(BaseModel):
    
    会社
    
    belong_user = models.CharField(verbose_name='所属ユーザ', max_length=50)
    company_name = models.CharField(verbose_name='会社名', max_length=50)
    
    class Meta:
        unique_together=(('belong_user', 'company_name'))

    def __str__(self):
        return '{}, {}'.format(self.belong_user, self.company_name)
'''

class Nohin(BaseModel):
    '''納品；今回なし'''
    nohin_date = models.DateField(verbose_name='納品日')
    nohin_nohinsaki = models.CharField(verbose_name='納品先', max_length=50)
    nohin_total_price = models.IntegerField(verbose_name='合計金額')
    nohin_memo = models.TextField(verbose_name='メモ', max_length=200, null=True, blank=True)
    
    def __str__(self):
        return '{},{}'.format(self.nohin_date, self.nohin_nohinsaki)
        
class NohinDetail(BaseModel):
    '''納品詳細；今回なし'''
    nohindetail_jan_code = models.CharField(verbose_name='JANコード', max_length=13)
    nohindetail_price = models.IntegerField(verbose_name='単価')
    nohindetail_amount = models.IntegerField(verbose_name='数量')
    '''
    #外部
    nohin = models.ForeignKey(Nohin, verbose_name='納品', on_delete=models.CASCADE)
    '''
    def __str__(self):
        return '{},{},{}'.format(self.nohindetail_jan_code, self.nohindetail_price, self.nohindetail_amount)
        