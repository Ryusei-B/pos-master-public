"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.urls import path
from django.contrib import admin
from django.views.generic import TemplateView
from django.views import View
from django.shortcuts import render
#from django.contrib.auth.mixins import LoginRequiredMixin
from django.conf import settings
from app_table.views import ShohinListView
from app_table.views import ShohinDeleteView
from app_table.views import ShohinRegistView
from app_table.views import ShohinUpdateView
#from app_table.views import NohinListView
#from app_table.views import NohinRegistView
#from app_table.views import NohinUpdateView
#from app_table.views import NohinDeleteView
#from app_table.views import DeliveryNoteView

class HomeView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'home.html', {})

urlpatterns = [
    url('admin/', admin.site.urls),
    path('', TemplateView.as_view(template_name='top.html'), name='top'),
    path('home/', HomeView.as_view(), name='home'),
    path('shohin/list/', ShohinListView.as_view(), name='shohin_list_view'),
    path('shohin/list/delete/', ShohinDeleteView.as_view(), name='shohin_delete_view'),
    path('shohin/list/regist/', ShohinRegistView.as_view(), name='shohin_regist_view'),
    path('shohin/list/updaete/', ShohinUpdateView.as_view(), name='shohin_update_view'),
    #path('nohin/list/', NohinListView.as_view(), kwargs={'mode': 'list'}, name='nohin_list_view'),
    #path('delivery_note_list/', NohinListView.as_view(), kwargs={'mode': 'pdf_list'}, name='nohin_list_view_deivery_note'),
    #path('nohin/list/regist/', NohinRegistView.as_view(), name='nohin_regist_view'),
    #path('nohin/list/delete/', NohinDeleteView.as_view(), name='nohin_delete_view'),
    #path('nohin/list/update/', NohinUpdateView.as_view(), name='nohin_update_view'),
#    path('delivery_note/', DeliveryNoteView.as_view(), name='delivery_note_view'),
]
